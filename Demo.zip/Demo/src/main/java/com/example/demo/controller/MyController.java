package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.repo.MyRepo;

@RestController
public class MyController {
	
	@Autowired
	private MyRepo repository;
	
	@PostMapping("/addEmployee")
	public String addEmployee(@RequestBody Employee employee) {
		repository.save(employee);
		return "Employee Added Successfully";
	}
	
}
